﻿$axure.loadCurrentPage(
(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,c,d,e,f,g,h,g,i,_(j,k),l,[m,n,o],p,_(q,r,s,t,u,v,w,_(),x,_(y,z,A,B,C,_(D,E,F,G),H,null,I,J,K,J,L,M,N,null,O,P,Q,R,S,T,U,P),V,_(),W,_(),X,_(Y,[])),Z,_(),ba,_());}; 
var b="url",c="账户管理.html",d="generationDate",e=new Date(1509515559214),f="isCanvasEnabled",g=false,h="isAdaptiveEnabled",i="sketchKeys",j="",k="s0",l="variables",m="OnLoadVariable",n="rl_date",o="rl_day",p="page",q="packageId",r="c50042cadc6b47caaaa3345c6ba49555",s="type",t="Axure:Page",u="name",v="账户管理",w="notes",x="style",y="baseStyle",z="627587b6038d43cca051c114ac41ad32",A="pageAlignment",B="center",C="fill",D="fillType",E="solid",F="color",G=0xFFFFFFFF,H="image",I="imageHorizontalAlignment",J="near",K="imageVerticalAlignment",L="imageRepeat",M="auto",N="favicon",O="sketchFactor",P="0",Q="colorStyle",R="appliedColor",S="fontName",T="Applied Font",U="borderWidth",V="adaptiveStyles",W="interactionMap",X="diagram",Y="objects",Z="masters",ba="objectPaths";
return _creator();
})());